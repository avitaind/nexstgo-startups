<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __( 'Builder', 'fw' );
$manifest['version'] = '1.2.3';
$manifest['github_update'] = 'ThemeFuse/Unyson-Builder-Extension';
