<?php if (!defined('FW')) die('Forbidden');

class FW_Extension_Builder extends FW_Extension
{
	/**
	 * @internal
	 */
	protected function _init()
	{
	}
}