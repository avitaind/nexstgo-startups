<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg          = array();
$cfg['items'] = array();

//Define default Forms items default width. Forms takes the middle value
$cfg['items']['width'] = '1_2';