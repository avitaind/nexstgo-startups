<?php if (!defined('FW')) die('Forbidden');

require dirname(__FILE__) . '/page-builder/class-fw-option-type-page-builder.php';
