<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

/**
 * Webmasters you want to use
 * At the moment are supported only Google and Bing.
 */
$cfg['webmasters'] = array( 'google', 'bing' );